import React, { useState, useEffect } from 'react';

const DateTime = () => {
  const [currentDateTime, setCurrentDateTime] = useState(new Date());

  useEffect(() => {
    const intervalId = setInterval(() => {
      setCurrentDateTime(new Date());
    }, 1000);

    return () => clearInterval(intervalId);
  }, []);

  return (
    
    <span class="badge text-bg-warning">
    <h6 className="text-muted">{currentDateTime.toLocaleDateString()}</h6>
      <h6 className="text-muted">{currentDateTime.toLocaleTimeString()}</h6>
      </span>

      

  );
};

export default DateTime;



