import React, { useState } from 'react';
import { Navbar } from './Components/Navbar';
import { NewsBoard } from './Components/NewsBoard';
import DateTime from './Components/DateTime';


const App = () => {
  const [category, setCategory] = useState('general');

  return (
    <div className="d-flex flex-column min-vh-100">
      <Navbar setCategory={setCategory} />
      
      <div className="container mt-4 flex-grow-1">
        <NewsBoard category={category} />
        <div className="container mt-4">
        {/* Date and Time Component */}
        <DateTime />
      </div>
   </div>
    </div>
  );
}

export default App;
